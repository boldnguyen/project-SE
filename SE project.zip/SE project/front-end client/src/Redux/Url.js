export const URL = process.env.REACT_APP_SERVER_URL;
