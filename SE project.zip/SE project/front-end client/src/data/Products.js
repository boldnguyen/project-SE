const products = [
  {
    _id: "1",
    name: "Black Boots",
    image: "/images/6.png",
    description:
      "Boots",
    price: 89,
    countInStock: 3,
    rating: 4,
    numReviews: 4,
  },
  {
    _id: "2",
    name: "Adidas Superstar Footwear White Black",
    image: "/images/5.png",
    description:
      "Adidas",
    price: 599,
    countInStock: 10,
    rating: 2,
    numReviews: 2,
  },
  {
    _id: "3",
    name: "Vans Old Skool",
    image: "/images/4.png",
    description:
      "van",
    price: 929,
    countInStock: 0,
    rating: 3.5,
    numReviews: 3,
  },
  {
    _id: "4",
    name: "Sneakers Basketball shoe",
    image: "/images/3.png",
    description:
      "Nike",
    price: 399,
    countInStock: 10,
    rating: 5,
    numReviews: 9,
  },
  {
    _id: "5",
    name: "Jordan",
    image: "/images/2.png",
    description:
      "From MJ",
    price: 49,
    countInStock: 7,
    rating: 2,
    numReviews: 2,
  },
  {
    _id: "6",
    name: "Yeezy Boost 350 V2 Black Red",
    image: "/images/1.png",
    description:
      "From Kanye West",
    price: 29,
    countInStock: 0,
    rating: 0,
    numReviews: 0,
  },
  {
    _id: "7",
    name: "Red",
    image: "/images/7.png",
    description:
      "cartoon",
    price: 9,
    countInStock: 0,
    rating: 0,
    numReviews: 0,
  }
  
];

export default products;
